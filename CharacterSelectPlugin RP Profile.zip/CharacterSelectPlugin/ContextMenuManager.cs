using Dalamud.Game.Gui.ContextMenu;
using Dalamud.Game.Text.SeStringHandling;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using System;
using Dalamud.Plugin.Services;
using System.Linq;
using System.Threading.Tasks;

namespace CharacterSelectPlugin.Managers;

public class ContextMenuManager : IDisposable
{
    private readonly Plugin plugin;
    private readonly IContextMenu contextMenu;

    private static readonly string[] ValidAddons =
    [
        "PartyMemberList",
        "FriendList",
        "FreeCompany",
        "LinkShell",
        "CrossWorldLinkshell",
        "_PartyList",
        "ChatLog",
        "LookingForGroup",
        "BlackList",
        "ContentMemberList",
        "SocialList",
        "ContactList",
    ];

    public ContextMenuManager(Plugin plugin, IContextMenu contextMenu)
    {
        this.plugin = plugin;
        this.contextMenu = contextMenu;
        this.contextMenu.OnMenuOpened += OnMenuOpened;
    }

    public void Dispose()
    {
        this.contextMenu.OnMenuOpened -= OnMenuOpened;
    }

    private void OnMenuOpened(IMenuOpenedArgs args)
    {
        if (args.Target is not MenuTargetDefault def || !ValidAddons.Any(x => x == args.AddonName))
            return;

        var name = def.TargetName;
        var world = def.TargetHomeWorld.RowId;

        if (string.IsNullOrEmpty(name) || world == 0)
            return;

        args.AddMenuItem(new MenuItem
        {
            Name = "🔍 View RP Profile",
            OnClicked = _ => Task.Run(() => plugin.TryRequestRPProfile(name)),
            IsEnabled = true
        });
    }
}
