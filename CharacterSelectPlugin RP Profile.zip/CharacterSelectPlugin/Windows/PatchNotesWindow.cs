using Dalamud.Interface.Windowing;
using ImGuiNET;
using System.Numerics;

namespace CharacterSelectPlugin.Windows
{
    public class PatchNotesWindow : Window
    {
        private readonly Plugin plugin;

        public PatchNotesWindow(Plugin plugin) : base("✨ Character Select+ – What's New?", ImGuiWindowFlags.AlwaysAutoResize)
        {
            this.plugin = plugin;
            IsOpen = false; // Hidden by default
        }

        public override void Draw()
        {
            ImGui.PushTextWrapPos();

            // 💚 Version Header
            ImGui.TextColored(new Vector4(0.2f, 1.0f, 0.2f, 1.0f), $"★ New in v{Plugin.CurrentPluginVersion}");
            ImGui.Separator();
            ImGui.Spacing();

            // 🌟 New Features Section (Header)
            ImGui.TextColored(new Vector4(0.65f, 0.65f, 0.9f, 1.0f), "🆕 New Features");
            ImGui.Spacing();

            // 🎯 Glamourer Automations
            ImGui.TextColored(new Vector4(0.8f, 0.95f, 1.0f, 1.0f), "• Glamourer Automations for Designs");
            ImGui.BulletText("Designs can now trigger specific Glamourer Automation profiles.");
            ImGui.BulletText("This is *opt-in* — toggle it in plugin settings.");
            ImGui.BulletText("If no automation is assigned, the design defaults to 'None'.");

            ImGui.Spacing();
            ImGui.Text("To avoid errors, set up a 'None' automation:");
            ImGui.BulletText("1. Open Glamourer > Automations.");
            ImGui.BulletText("2. Create an Automation named 'None'.");
            ImGui.BulletText("3. Add your in-game character name beside 'Any World'.");
            ImGui.BulletText("4. That's it. Don't touch anything else, you're done!");

            ImGui.Spacing();

            // 🧩 Other Major Features
            ImGui.TextColored(new Vector4(0.8f, 0.95f, 1.0f, 1.0f), "• RP Profile Panel");
            ImGui.BulletText("Track pronouns, age, bio, and more with each character.");

            ImGui.TextColored(new Vector4(0.8f, 0.95f, 1.0f, 1.0f), "• Customize+ Profiles in Designs");
            ImGui.BulletText("Each design now supports its own Customize+ profile.");

            ImGui.TextColored(new Vector4(0.8f, 0.95f, 1.0f, 1.0f), "• Manual Character Reordering");
            ImGui.BulletText("Drag and drop profiles to reorder them.");

            ImGui.TextColored(new Vector4(0.8f, 0.95f, 1.0f, 1.0f), "• Character Search Bar");
            ImGui.BulletText("Quickly find characters by name.");

            ImGui.TextColored(new Vector4(0.8f, 0.95f, 1.0f, 1.0f), "• Right-click → Apply to Target");
            ImGui.BulletText("Applies the macro to your selected target.");

            ImGui.TextColored(new Vector4(0.8f, 0.95f, 1.0f, 1.0f), "• Copy Designs Between Characters");
            ImGui.BulletText("Easily reuse Designs by copying them across characters.");

            ImGui.Spacing();
            ImGui.Separator();
            ImGui.Spacing();

            // 🔧 Other Changes Section
            ImGui.TextColored(new Vector4(0.65f, 0.65f, 0.9f, 1.0f), "🛠 Other Changes");
            ImGui.BulletText("Older Design macros were automatically upgraded.");
            ImGui.BulletText("Various UI tweaks, bugfixes, and behind-the-scenes improvements.");

            ImGui.Spacing();
            ImGui.Spacing();

            if (ImGui.Button("Got it!"))
            {
                plugin.Configuration.LastSeenVersion = Plugin.CurrentPluginVersion;
                plugin.Configuration.Save();
                IsOpen = false;
                plugin.ToggleMainUI(); // auto-open Character Select+
            }

            ImGui.PopTextWrapPos();
        }
    }
}
